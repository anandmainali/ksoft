<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyPrivateEmail extends Model
{
    protected $fillable = ['company_private_email'];
}
